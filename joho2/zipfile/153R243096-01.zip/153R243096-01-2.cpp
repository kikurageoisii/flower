#include<stdio.h>

void csv_scan(const char file[],int array[],int size){
    FILE* ipfp=fopen(file,"r");
    
    if(ipfp==NULL) return;
    
    for (int i = 0; i < size; i++)
    {
        if(fscanf(ipfp,"%d\n",&array[i])!=1)break;
    }

    fclose(ipfp);
}

int main(){
    const int N=10; //あとで50に変更
    int a[N];
    csv_scan("date50.txt",&a[N],N);

}